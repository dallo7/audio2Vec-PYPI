from audio2vec import Audio2Vec

obj = Audio2Vec(nFeatures=5)

print(obj.audio2Vec2DfProcessor("abuse_female_scream.wav"))

